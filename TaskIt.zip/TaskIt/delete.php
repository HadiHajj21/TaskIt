<?php

session_start();
require 'connection.php';
require 'functions.php';
require 'database.php';

$config = require('partials/config.php');

$db = new Database($config['database']);

    $note['id'] = $_GET['noteId'];
    
    $result = $db->query("DELETE FROM notes WHERE id = " . $note['id']);

    if ($result) {
        echo 'success';
    } else {
        echo 'error';
    }

header("Location: index.php");
die();