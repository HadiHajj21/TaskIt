<?php
session_start();

include("connection.php");
include("functions.php");


if($_SERVER['REQUEST_METHOD'] == "POST"){
    //something was posted
    $user_first_name = $_POST['first-name'];
    $user_last_name = $_POST['last-name'];
    $user_email = $_POST['user-email'];
    $password = $_POST['password'];

    $user_name = $user_first_name . " " . $user_last_name;

    $user_id = random_num(20);

    //save to database
    $query = "insert into users(user_id,user_name,user_email,password) values('$user_id','$user_name','$user_email','$password')";

    mysqli_query($con,$query);
    header("Location: login.php");
    die;

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style type="text/css">
        html{
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
        }

        a {
            text-decoration: none;
        }
        body {
            background: -webkit-linear-gradient(bottom, #190404, #950606);
            background-repeat: no-repeat;
            height: 100%;
            width: 100%;
            margin: 0;
            display: flex;
            align-content: center;
            flex-wrap: wrap;
            justify-content: center;
        }
        label {
            font-family: "Raleway", sans-serif;
            font-size: 11pt;
        }
        #forgot-pass {
            color: #2dbd6e;
            font-family: "Raleway", sans-serif;
            font-size: 10pt;
            margin-top: 3px;
            text-align: right;
        }
        #card {
            background: #fbfbfb;
            border-radius: 8px;
            box-shadow: 1px 2px 8px rgba(0, 0, 0, 0.65);
            height: fit-content;
            width: 329px;
        }
        #card-content {
            padding: 12px 44px;
        }
        #card-title {
            font-family: "Raleway Thin", sans-serif;
            letter-spacing: 4px;
            padding-bottom: 23px;
            padding-top: 13px;
            text-align: center;
        }
        #signup {
            color: #2dbd6e;
            font-family: "Raleway", sans-serif;
            font-size: 10pt;
            margin-top: 16px;
            text-align: center;
        }
        #submit-btn {
            background: -webkit-linear-gradient(right, #190404, #950606);
            border: none;
            border-radius: 21px;
            box-shadow: 0px 1px 8px #24c64f;
            cursor: pointer;
            color: white;
            font-family: "Raleway SemiBold", sans-serif;
            height: 42.3px;
            margin: 0 auto;
            margin-top: 50px;
            transition: 0.25s;
            width: 153px;
        }
        #submit-btn:hover {
            box-shadow: 0px 1px 18px #c62424;
        }
        .form {
            align-items: left;
            display: flex;
            flex-direction: column;
        }
        .form-border {
            background: -webkit-linear-gradient(right, #a6f77b, #2ec06f);
            height: 1px;
            width: 100%;
        }
        .form-content {
            background: #fbfbfb;
            border: none;
            outline: none;
            padding-top: 14px;
        }
        .underline-title {
            background: -webkit-linear-gradient(right, #a6f77b, #2ec06f);
            height: 2px;
            margin: -1.1rem auto 0 auto;
            width: 89px;
        }
        #intro{
            text-align: center;
            font-family: "Raleway", sans-serif;
        }
        
        #rememberMe{
            margin: 10px 0 0 0;
            display:inline-block;
            width:auto;
        }

    </style>
    <title>SignUp</title>
</head>
<body>
    <div id="card">
        <div id="card-content">
          <div id="card-title">
            <h2>SIGN UP</h2>
            <div class="underline-title"></div>
          </div>

          <form id="myForm" method="post" class="form">

            <label for="first-name" style="padding-top:13px">
                &nbsp;First Name
            </label>

            <input id="first-name" class="form-content" type="text" name="first-name" required/>

            <div class="form-border"></div>

            <label for="last-name" style="padding-top:13px">
                &nbsp;Last Name
            </label>

            <input id="last-name" class="form-content" type="text" name="last-name" required />

            <div class="form-border"></div>

            <label for="user-email" style="padding-top:13px">
                &nbsp;Email
            </label>

            <input id="user-email" class="form-content" type="text" name="user-email" required autocomplete="on"/>

            <div class="form-border"></div>

            <label for="user-password" style="padding-top:22px">
                &nbsp;Password
            </label>

            <input id="user-password" class="form-content" type="password" name="password" required/>

            <div class="form-border"></div>

            <input id="submit-btn" type="submit" name="submit" value="SIGN UP" />


          </form>
    </div>
</div>
</body>
</html>