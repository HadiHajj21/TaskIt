<?php
session_start();

include("connection.php");
include("functions.php");
require 'database.php';

$user_data = check_login($con);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    html,
    body {
      margin: 0;
      padding: 0;
      height: 100vh;
      width: 100vw;
    }

    * {
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: "Raleway", sans-serif;
      height: 100vh;
      width: 100vw;
      background-color: #111;
      color: #999;
    }

    .navbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20px;
      background: -webkit-linear-gradient(bottom, #190404, #950606);
      background-repeat: no-repeat;
      color: #fff;
      height: 4vw;
      border-radius: 10px;
    }

    .nav-links a {
      color: #fff;
    }

    .menu {
      display: flex;
      gap: 1em;
      font-size: 18px;
    }

    .nav-links {
      text-align: center;
    }

    .nav-links li {
      padding: 5px 14px;
      display: inline-block;
      margin-right: 15px;
      transition: all 0.3s ease-in-out;
    }

    .nav-links li:hover a {
      background-color: #950606;
      border-radius: 5px;
      transition: 0.3s ease;
    }

    .nav-links li:hover a::before {
      visibility: visible;
      transform: scale(1, 1);
    }

    .nav-links li a {
      color: #999;
      display: block;
      padding: 0 7px 0 7px;
      margin: 0 0 10px;
      text-decoration: none;
      position: relative;
    }

    .nav-links li a::before {
      content: "";
      position: absolute;
      width: 100%;
      height: 3px;
      bottom: -10px;
      left: 0px;
      background-color: #fff;
      transition: all 0.2s ease-in-out;
      transform: scale(0, 0);
      visibility: hidden;
    }

    input[type=checkbox] {
      display: none;
    }

    /* HAMBURGER MENU */
    .hamburger {
      display: none;
      font-size: 24px;
      user-select: none;
    }

    .hamburger:hover {
      cursor: pointer;
      background-color: #950606;
      border-radius: 5px;
      transition: 0.3s ease;
    }

    @media screen and (max-width: 768px) {
      .menu {
        display: none;
        position: absolute;
        background-image: linear-gradient(#950606, #190404);
        right: 0;
        left: 0;
        text-align: center;
        padding: 16px 0;
        z-index: 3;
      }

      #greeting {
        font-size: 25px;
      }

      .menu li {
        width: 100%;
        position: center;
      }

      .menu li:hover {
        display: inline-block;
        transition: 0.3s ease;
      }

      .menu li+li {
        margin-top: 12px;
      }

      #checkbox_toggle:checked~.menu {
        display: block;
      }

      .hamburger {
        display: block;
      }

      .calendar {
        z-index: -1;
      }

    }

    .logo {
      font-size: xx-large;
    }

    #greeting {
      text-align: left;
      font-weight: bold;
      font-size: 30px;
      font-family: Verdana, Geneva, Tahoma, sans-serif;
      margin-left: 30px;
    }

    .ques {
      font-size: 18px;
      color: #999;
      margin-top: 0;
      font-weight: normal;
      height: 50px;
      width: 100%;
    }

    .sidenav {
      height: 100%;
      /* Full-height: remove this if you want "auto" height */
      width: 160px;
      /* Set the width of the sidebar */
      position: fixed;
      /* Fixed Sidebar (stay in place on scroll) */
      z-index: 1;
      /* Stay on top */
      left: 0;
      background-color: #111;
      /* Black */
      overflow-x: hidden;
      /* Disable horizontal scroll */
      padding-top: 20px;
    }

    #current_date {
      width: 100px;
      text-align: center;
      display: inline-block;
    }

    .main_droppable {
      height: 72vh;
      margin-left: 30px;
    }

    .main {
      padding-top: 20px;
      margin: 0 15% 0 15%;
    }

    #current_date p {
      margin: 0px;
    }

    .calendar {
      overflow: hidden;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-evenly;
      position: relative;
      z-index: auto;
    }

    .mot {
      display: inline-block;
    }

    .entries {
      height: 60vh;
      position: relative;
    }

    .entry_addtask {
      position: absolute;
      bottom: 15px;
      display: block;
      width: 100%;
    }

    textarea {
      width: 100%;
      height: 40px;
      border-radius: 8px;
      border-color: gray;
      background-color: transparent;
      padding: 10px;
      font-family: "Raleway", sans-serif;
      font-size: medium;
      display: inline;
      font-weight: 600;
      resize:none;
    }

    textarea:hover {
      border: solid thin red;
      border-radius: 8px;
      transition: 0.1s ease-in;
    }

    textarea:focus {
      background-color: #1e1e1e;
      border-color: gray;
      color: white;
    }

    textarea:focus-visible {
      outline: none;
    }

    textarea::placeholder {
      color: #999;
      font-size: medium;
      font-family: "Raleway", sans-serif;
      font-weight: 400;
    }

    #my_form {
      display: flex;
      flex-wrap: wrap;
      align-content: center;
      align-items: center;
      justify-content: space-around;
    }

    #btn {
      text-align: center;
      transition-duration: 0.4s;
      background-color: transparent;
      color: #999;
      border: 2px solid #999;
      border-radius: 12px;
      padding: 10px 24px;
    }

    #btn:hover {
      background-color: #999999;
      color: black;
    }

    .entries_wrapper {
      display: grid;
      gap: 13px;
      padding: 18px;
    }

    .T {
      padding-top: 5px;
      overflow-y: scroll;
      height: 250px;
      display: flex;
      align-content: flex-start;
      flex-wrap: wrap;
      justify-content: center;
    }

    .T::-webkit-scrollbar {
      width: 5px;
    }

    .T::-webkit-scrollbar-track {
      -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
      border-radius: 5px;
    }

    .T::-webkit-scrollbar-thumb {
      border-radius: 5px;
      -webkit-box-shadow: inset 0 0 6px red;
    }

    .divT:hover{
      fill:red;
      color:red;
    }

    .deletion{
      font-size: xx-small;
    }

    .deletion:hover{
      color:red;
    }

    .link{
      color:inherit;
    }
  </style>
  <script>

    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }

    document.getElementById("body").addEventListener("keydown", function(event) {
            // Check if the Enter key (key code 13) is pressed
            if (event.keyCode === 13) {
                event.preventDefault(); // Prevent the default newline behavior
                document.getElementById("my_form").submit(); // Submit the form
            }
        });

  </script>
  <title>TaskIt</title>
</head>

<body>
  <?php require "partials/nav.php"; ?>

  <div class="main">

    <div id="greeting">

      Hello, <?php require 'partials/greeting.php'; ?><br>

      <p class="ques">What's your plan for today ?</p>

    </div>

    <div class="main_droppable">

      <div class="calendar">

        <?php require 'partials/calender.php'; ?>

      </div>
      <div class="entries">

        <div class="entries_wrapper">

          <div class="T">
            <?php
            if ($user_data !== null) {

              $config = require('partials/config.php');

              $db = new Database($config['database']);

              $notes = $db->query('select * from notes where user_id = :id', ['id' => $user_data['id']])->fetchAll();

              foreach ($notes as $note) {

                echo '<div style="position:relative;width:75%;line-height:30px;text-align:center;height:30px;border-radius:8px;font-size:large;margin:5px;transition: transform 200ms ease 0s;background-color:#999;color:black;">'
                  . $note['body'] .' <a class="link" href="delete.php?noteId='. $note['id'] .'">
                  <div class="divT"  style="position: absolute;width: 98px;height: 100%;right: 0;top: 0;display: flex;flex-wrap: wrap;justify-content: space-evenly;align-items: center;">
                  <span class="deletion">Delete this note</span>
                    <svg class="link" xmlns="http://www.w3.org/2000/svg" height="0.625em" viewBox="0 0 384 512">
                      <path d="M376.6 84.5c11.3-13.6 9.5-33.8-4.1-45.1s-33.8-9.5-45.1 4.1L192 206 56.6 43.5C45.3 29.9 25.1 28.1 11.5 39.4S-3.9 70.9 7.4 84.5L150.3 256
                      7.4 427.5c-11.3 13.6-9.5 33.8 4.1 45.1s33.8 9.5 45.1-4.1L192 306 327.4 468.5c11.3 13.6 31.5 15.4 45.1 4.1s15.4-31.5 4.1-45.1L233.7 256 376.6 84.5z"/>
                      </svg>
                  </div>
                  </a></div>';
              }

            }
            ?>
          </div>
          <?php require 'partials/Entry.php'; ?>
        </div>

        <div class="entry_addtask">

          <div class="addtask">

            <?php require 'partials/limiter.php'; ?>

            <form onsubmit="setTimeout(function(){window.location.reload();},10);" id="my_form" class="fk1"
              method="POST" action="">

              <?php if (isset($errors['body'])): ?>
                <p style="color:red; font-size:small;margin-left:10px;"><?= $errors['body'] ?> </p>
              <?php endif; ?>

              <textarea name="body" id="body" placeholder='Enter task title' <?php if ($user_data == null) {
                echo 'disabled style="cursor:not-allowed;"';
              } ?>><?= isset($errors['body']) ? $_POST['body'] : '' ?></textarea>

              <button id="btn" type="submit" class="submit" value="submit" <?php if ($user_data == null) {
                echo 'disabled style="cursor:not-allowed;"';
              } ?>> Submit </button>


          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  </div>

</body>

</html>