<?php

return [
    'database' => [
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => 'login_sample_db',
        'charset' => 'utf8mb4'
    ],

    
    ];