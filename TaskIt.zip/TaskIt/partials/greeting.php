<?php
if ($user_data == null){
    echo 'Guest';
}else {
    echo $user_data['user_name'];
}
