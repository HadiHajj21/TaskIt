<nav class="navbar">
    <!-- LOGO -->
    <div class="logo">TaskIt</div>

    <!-- NAVIGATION MENU -->
    <ul class="nav-links">

      <!-- USING CHECKBOX HACK -->
      <input type="checkbox" id="checkbox_toggle" />
      <label for="checkbox_toggle" class="hamburger">&#9776;</label>

      <!-- NAVIGATION MENUS -->
      <div class="menu">
        <li><a href="/">Home</a></li>
        <li><a href="/">About</a></li>
        <li><a href="/">Pricing</a></li>
        <li><a href="/">Contact</a></li>
        <li><?php
          if ($user_data == null){
            echo '<a href="login.php">LogIn</a>';
          }else{
            echo '<a href="logout.php">Logout</a>';
          }
            ?>
        </li>
      </div>
    </ul>
  </nav>