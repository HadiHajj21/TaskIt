<?php

//Connect to the databse and execute a query
$config = require ('config.php');

$db = new Database($config['database']);

$notes = $db -> query('select * from notes')->fetchAll();

if ($user_data == null){
  echo '<p style="text-align: center;
  background-color: darkgrey;
  padding: 10px;
  color: red;
  position: absolute;
  right: 0;
  left: 0;">' . "Please <a href='login.php'>LogIn</a> or <a href='signup.php'>SignUp</a> to start adding tasks" . '</p>';
}