<div id="current_date">
              <?php
            $currentDateTime = new DateTime('now'); ?>
      
            <p><?php echo $currentDateTime->format('D');?></p>
            <p style="font-weight: 900;font-size: xx-large;"><?php echo $currentDateTime->format('j');?></p>
            <p><?php echo $currentDateTime->format('F'); ?> </p>
            </div>
            <div class="mot" style="display:inline-block">
              <p>Do the ImPossible</p>
            </div>
            